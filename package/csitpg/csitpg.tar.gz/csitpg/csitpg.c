#include <linux/delay.h>
#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/io.h>
#include <linux/module.h>
#include <linux/of_graph.h>
#include <linux/slab.h>
#include <linux/videodev2.h>
#include <linux/version.h>
#include <linux/rk-camera-module.h>
#include <linux/compat.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-device.h>
#include <media/v4l2-fwnode.h>
#include <media/v4l2-image-sizes.h>
#include <media/v4l2-mediabus.h>
#include <linux/of_device.h>

#define CSITPG_NAME			"csitpg"

static const s64 link_freq_menu_items[] = {
	456000000,
};

struct csitpg_mode {
	u32 width;
	u32 height;
	struct v4l2_fract max_fps;
	u32 nlines; // num csi lines
	u32 format_code;
};

struct csitpg {
	struct v4l2_subdev subdev;
	struct media_pad pad;
	struct v4l2_ctrl_handler ctrl_handler;

	struct csitpg_mode cur_mode;

	u32 module_index;
	const char *module_facing;
	const char *module_name;
	const char *len_name;
};

static struct csitpg *to_csitpg(const struct i2c_client *client)
{
	return container_of(i2c_get_clientdata(client), struct csitpg, subdev);
}

/* V4L2 subdev video operations */
static int csitpg_s_stream(struct v4l2_subdev *sd, int enable)
{
//	struct i2c_client *client = v4l2_get_subdevdata(sd);
//	struct csitpg *priv = to_csitpg(client);
	return 0;
}

/* V4L2 subdev core operations */
static int csitpg_s_power(struct v4l2_subdev *sd, int on)
{
	return 0;
}

static int csitpg_g_frame_interval(struct v4l2_subdev *sd,
				   struct v4l2_subdev_frame_interval *fi)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	fi->interval = priv->cur_mode.max_fps;

	return 0;
}

static int csitpg_enum_mbus_code(struct v4l2_subdev *sd,
				 struct v4l2_subdev_state *cfg,
				 struct v4l2_subdev_mbus_code_enum *code)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	if (code->index != 0)
		return -EINVAL;
	code->code = priv->cur_mode.format_code;
	return 0;
}

static int csitpg_set_fmt(struct v4l2_subdev *sd,
			  struct v4l2_subdev_state *cfg,
			  struct v4l2_subdev_format *fmt)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	if (fmt->which == V4L2_SUBDEV_FORMAT_TRY)
		return 0;

	fmt->format.code = priv->cur_mode.format_code;
	fmt->format.width = priv->cur_mode.width;
	fmt->format.height = priv->cur_mode.height;
	fmt->format.field = V4L2_FIELD_NONE;
	return 0;
}

static int csitpg_get_fmt(struct v4l2_subdev *sd,
			  struct v4l2_subdev_state *cfg,
			  struct v4l2_subdev_format *fmt)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	if (fmt->which == V4L2_SUBDEV_FORMAT_TRY)
		return 0;

	fmt->format.width = priv->cur_mode.width;
	fmt->format.height = priv->cur_mode.height;
	fmt->format.code = priv->cur_mode.format_code;
	fmt->format.field = V4L2_FIELD_NONE;

	return 0;
}

static int csitpg_g_mbus_config(struct v4l2_subdev *sd, unsigned int pad_id,
				struct v4l2_mbus_config *config)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	config->type = V4L2_MBUS_CSI2_DPHY;
	config->bus.mipi_csi2.num_data_lanes = priv->cur_mode.nlines;

	return 0;
}

static void csitpg_get_module_inf(struct csitpg *csitpg,
				  struct rkmodule_inf *inf)
{
	memset(inf, 0, sizeof(*inf));
	strlcpy(inf->base.sensor, CSITPG_NAME, sizeof(inf->base.sensor));
	strlcpy(inf->base.module, csitpg->module_name,
		sizeof(inf->base.module));
	strlcpy(inf->base.lens, csitpg->len_name, sizeof(inf->base.lens));
}

static long csitpg_ioctl(struct v4l2_subdev *sd, unsigned int cmd, void *arg)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *csitpg = to_csitpg(client);
	long ret = 0;

	switch (cmd) {
	case RKMODULE_GET_MODULE_INFO:
		csitpg_get_module_inf(csitpg, (struct rkmodule_inf *)arg);
		break;
	default:
		ret = -ENOIOCTLCMD;
		break;
	}

	return ret;
}

#ifdef CONFIG_COMPAT
static long csitpg_compat_ioctl32(struct v4l2_subdev *sd,
				  unsigned int cmd, unsigned long arg)
{
	void __user *up = compat_ptr(arg);
	struct rkmodule_inf *inf;
	struct rkmodule_awb_cfg *cfg;
	long ret;

	switch (cmd) {
	case RKMODULE_GET_MODULE_INFO:
		inf = kzalloc(sizeof(*inf), GFP_KERNEL);
		if (!inf) {
			ret = -ENOMEM;
			return ret;
		}

		ret = csitpg_ioctl(sd, cmd, inf);
		if (!ret)
			ret = copy_to_user(up, inf, sizeof(*inf));
		kfree(inf);
		break;
	case RKMODULE_AWB_CFG:
		cfg = kzalloc(sizeof(*cfg), GFP_KERNEL);
		if (!cfg) {
			ret = -ENOMEM;
			return ret;
		}

		ret = copy_from_user(cfg, up, sizeof(*cfg));
		if (!ret)
			ret = csitpg_ioctl(sd, cmd, cfg);
		kfree(cfg);
		break;
	default:
		ret = -ENOIOCTLCMD;
		break;
	}
	return ret;
}
#endif

static int csitpg_enum_frame_interval(struct v4l2_subdev *sd,
				       struct v4l2_subdev_state *cfg,
				       struct v4l2_subdev_frame_interval_enum *fie)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);

	if (fie->index >= 1)
		return -EINVAL;

	if (fie->code != priv->cur_mode.format_code)
		return -EINVAL;

	fie->code = priv->cur_mode.format_code;
	fie->width = priv->cur_mode.width;
	fie->height = priv->cur_mode.height;
	fie->interval = priv->cur_mode.max_fps;
	return 0;
}

/* Various V4L2 operations tables */
static struct v4l2_subdev_video_ops csitpg_subdev_video_ops = {
	.s_stream = csitpg_s_stream,
	.g_frame_interval = csitpg_g_frame_interval,
};

static struct v4l2_subdev_core_ops csitpg_subdev_core_ops = {
	.s_power = csitpg_s_power,
	.ioctl = csitpg_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl32 = csitpg_compat_ioctl32,
#endif
};

static const struct v4l2_subdev_pad_ops csitpg_subdev_pad_ops = {
	.enum_mbus_code = csitpg_enum_mbus_code,
	.enum_frame_interval = csitpg_enum_frame_interval,
	.set_fmt = csitpg_set_fmt,
	.get_fmt = csitpg_get_fmt,
	.get_mbus_config = csitpg_g_mbus_config,
};

static struct v4l2_subdev_ops csitpg_subdev_ops = {
	.core = &csitpg_subdev_core_ops,
	.video = &csitpg_subdev_video_ops,
	.pad = &csitpg_subdev_pad_ops,
};

static int force_w = 0;
module_param(force_w, int, 0444);
MODULE_PARM_DESC(force_w, "Force width");

static int force_h = 0;
module_param(force_h, int, 0444);
MODULE_PARM_DESC(force_h, "Force height");

static int force_nlines = 0;
module_param(force_nlines, int, 0444);
MODULE_PARM_DESC(force_nlines, "Force nlines");

static uint force_format = 0;
module_param(force_format, uint, 0444);
MODULE_PARM_DESC(force_format, "Force mbus format");

static int csitpg_board_inentify(struct i2c_client *client,
				 struct csitpg_mode *cur_mode)
{
	struct device *dev = &client->dev;

	cur_mode->max_fps.numerator = 10000;
	cur_mode->max_fps.denominator = 25000;

	cur_mode->width = 1920;
	cur_mode->height = 1080;
	cur_mode->nlines = 4;
	cur_mode->format_code = MEDIA_BUS_FMT_SRGGB12_1X12;
	if (force_format)
		cur_mode->format_code = force_format;
	if (force_w)
		cur_mode->width = force_w;
	if (force_h)
		cur_mode->height = force_h;
	if (force_nlines)
		cur_mode->nlines = force_nlines;
		
	dev_info(dev, "mode %ux%u nlines: %u, format: 0x%x\n",
		 cur_mode->width, cur_mode->height, cur_mode->nlines, cur_mode->format_code);

	return 0;
}

static int csitpg_ctrls_init(struct v4l2_subdev *sd)
{
	struct i2c_client *client = v4l2_get_subdevdata(sd);
	struct csitpg *priv = to_csitpg(client);
	int ret;

	v4l2_ctrl_handler_init(&priv->ctrl_handler, 10);

	/* freq */
	v4l2_ctrl_new_int_menu(&priv->ctrl_handler, NULL, V4L2_CID_LINK_FREQ,
			       0, 0, link_freq_menu_items);

	priv->subdev.ctrl_handler = &priv->ctrl_handler;
	if (priv->ctrl_handler.error) {
		dev_err(&client->dev, "Error %d adding controls\n",
			priv->ctrl_handler.error);
		ret = priv->ctrl_handler.error;
		goto error;
	}

	ret = v4l2_ctrl_handler_setup(&priv->ctrl_handler);
	if (ret < 0) {
		dev_err(&client->dev, "Error %d setting default controls\n",
			ret);
		goto error;
	}

	return 0;
error:
	v4l2_ctrl_handler_free(&priv->ctrl_handler);
	return ret;
}

static int csitpg_probe(struct i2c_client *client,
			const struct i2c_device_id *did)
{
	struct csitpg *priv;
	struct device *dev = &client->dev;
	struct device_node *node = dev->of_node;
	struct v4l2_subdev *sd;
	char facing[2];
	int ret;

	dev_info(dev, "probing csitpg sensor\n");
	priv = devm_kzalloc(&client->dev, sizeof(struct csitpg), GFP_KERNEL);
	if (!priv)
		return -ENOMEM;
	ret = of_property_read_u32(node, RKMODULE_CAMERA_MODULE_INDEX,
				   &priv->module_index);
	ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_FACING,
				       &priv->module_facing);
	ret |= of_property_read_string(node, RKMODULE_CAMERA_MODULE_NAME,
				       &priv->module_name);
	ret |= of_property_read_string(node, RKMODULE_CAMERA_LENS_NAME,
				       &priv->len_name);
	if (ret) {
		dev_err(dev, "could not get module information!\n");
		return -EINVAL;
	}
	ret = csitpg_board_inentify(client, &priv->cur_mode);
	if (ret != 0) {
		return ret;
	}

	v4l2_i2c_subdev_init(&priv->subdev, client, &csitpg_subdev_ops);
	ret = csitpg_ctrls_init(&priv->subdev);
	if (ret < 0)
		return ret;

	priv->subdev.flags |= V4L2_SUBDEV_FL_HAS_DEVNODE |
		     V4L2_SUBDEV_FL_HAS_EVENTS;
	priv->pad.flags = MEDIA_PAD_FL_SOURCE;
	priv->subdev.entity.function = MEDIA_ENT_F_CAM_SENSOR;
	ret = media_entity_pads_init(&priv->subdev.entity, 1, &priv->pad);
	if (ret < 0)
		return ret;

	sd = &priv->subdev;
	memset(facing, 0, sizeof(facing));
	if (strcmp(priv->module_facing, "back") == 0)
		facing[0] = 'b';
	else
		facing[0] = 'f';

	snprintf(sd->name, sizeof(sd->name), "m%02d_%s_%s %s",
		 priv->module_index, facing,
		 CSITPG_NAME, dev_name(sd->dev));
	ret = v4l2_async_register_subdev_sensor(sd);
	if (ret < 0)
		return ret;

	return ret;
}

static void csitpg_remove(struct i2c_client *client)
{
	struct csitpg *priv = to_csitpg(client);

	v4l2_async_unregister_subdev(&priv->subdev);
	media_entity_cleanup(&priv->subdev.entity);
	v4l2_ctrl_handler_free(&priv->ctrl_handler);
}

static const struct of_device_id csitpg_of_match[] = {
	{ .compatible = "inmys,csi-tester" },
	{ /* sentinel */ },
};
MODULE_DEVICE_TABLE(of, csitpg_of_match);


static const struct i2c_device_id csitpg_id[] = {
	{ "csi-tester", 0 },
	{}
};

MODULE_DEVICE_TABLE(i2c, csitpg_id);
static struct i2c_driver csitpg_i2c_driver = {
	.driver = {
		.of_match_table = of_match_ptr(csitpg_of_match),
		.name = CSITPG_NAME,
	},
	.probe = csitpg_probe,
	.remove = csitpg_remove,
	.id_table = csitpg_id,
};

module_i2c_driver(csitpg_i2c_driver);
MODULE_DESCRIPTION("Media Controller driver for csi_tester board");
MODULE_AUTHOR("Inmys <bond@inmys.ru>");
MODULE_LICENSE("GPL v2");
